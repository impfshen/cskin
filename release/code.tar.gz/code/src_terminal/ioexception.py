class IOException(Exception):
    def __init__(self,mesg="raise a IOException"):
        print (mesg)
