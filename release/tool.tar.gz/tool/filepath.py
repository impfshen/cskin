colorPath=r'/home/cskin/tool/color'
standardImg=r'/home/cskin/standardImg'
recordPath=r'/home/cskin/record'
